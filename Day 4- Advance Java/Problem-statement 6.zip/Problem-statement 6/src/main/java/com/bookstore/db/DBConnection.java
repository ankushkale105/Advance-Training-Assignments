package com.bookstore.db;

import java.sql.*;
import java.sql.DriverManager;

import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;

public class DBConnection {
	
	public static Connection getConnection() {
		Connection conn = null;
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore", "root", "Connect@10");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	// close connection
	public static void closeConnection(Connection conn) {
		try {
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}