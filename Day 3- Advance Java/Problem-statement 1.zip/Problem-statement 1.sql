create database productdb;
use products;
create table product(Product_Id  int primary key, Product_Name  varchar(20), Product_Price double);
desc product;

select * from product;
