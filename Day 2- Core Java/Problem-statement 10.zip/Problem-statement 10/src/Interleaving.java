import java.util.Scanner;

public class Interleaving {

	public static boolean isInterleaving(String a, String b, String c) {

		if (a.length() == 0 && b.length() == 0 && c.length() == 0) {
			return true;
		}

		if (c.length() == 0) {
			return false;
		}

		boolean x = (a.length() != 0 && c.charAt(0) == a.charAt(0))
				&& isInterleaving(a.substring(1), b, c.substring(1));

		boolean y = (b.length() != 0 && c.charAt(0) == b.charAt(0))
				&& isInterleaving(a, b.substring(1), c.substring(1));

		return x || y;
	}

	public static void main(String[] args) {

		Scanner ak = new Scanner(System.in);
		System.out.println("Enter The First String :");
		String a = ak.nextLine();
		System.out.println("Enter The Second String :");
		String b = ak.nextLine();
		System.out.println("Enter The Third String :");
		String c = ak.nextLine();

		if (isInterleaving(a, b, c)) {
			System.out.print("True : Third string is valid shuffle of first and second string");
		} else {
			System.out.print("False : Third string is NOT a valid shuffle of first and second string.");
		}
	}
}
