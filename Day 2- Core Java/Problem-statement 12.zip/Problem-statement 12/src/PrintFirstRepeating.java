
import java.util.*;

public class PrintFirstRepeating {

	// This function prints the first repeating element in arr[]
	static void printFirstRepeating(int arr[]) {

		// Initialize index of first repeating element
		int min = -1;

		// Creates an empty hashset
		HashSet<Integer> set = new HashSet<>();

		// Traverse the input array from right to left
		for (int i = arr.length - 1; i >= 0; i--) {
			// If element is already in hash set, update min
			if (set.contains(arr[i]))
				min = i;

			else // Else add element to hash set
				set.add(arr[i]);
		}

		// Print the result
		if (min != -1)
			System.out.println("First Repeated Element is : " + arr[min]);
		else
			System.out.println("There are no repeating elements");
	}

	// Driver method to test above method
	public static void main(String[] args) throws java.lang.Exception {

		// First Input
		int arr[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
		List<Integer> list = new ArrayList<>(); // To print array

		for (int i : arr) {
			list.add(i);
		}
		System.out.println("The given integer array is : " + list);
		printFirstRepeating(arr);

		// Second Input
		int arr1[] = { 1, 2, 3, 10, 6, 4, 3, 7, 10 };
		List<Integer> list1 = new ArrayList<>(); // To print array

		for (int i : arr) {
			list1.add(i);
		}
		System.out.println("\n*****************************************\n");
		System.out.println("The given integer array is : " + list1);
		printFirstRepeating(arr1);
	}
}
