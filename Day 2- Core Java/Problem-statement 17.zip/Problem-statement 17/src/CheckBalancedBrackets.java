
import java.util.*;

public class CheckBalancedBrackets {

	static boolean areBracketsBalanced(String expr) {

		Deque<Character> stack = new ArrayDeque<Character>();

		for (int i = 0; i < expr.length(); i++) {
			char x = expr.charAt(i);

			if (x == '(' || x == '[' || x == '{') {

				stack.push(x);
				continue;
			}

			if (stack.isEmpty())
				return false;
			char check;
			switch (x) {
			case ')':
				check = stack.pop();
				if (check == '{' || check == '[')
					return false;
				break;

			case '}':
				check = stack.pop();
				if (check == '(' || check == '[')
					return false;
				break;

			case ']':
				check = stack.pop();
				if (check == '(' || check == '{')
					return false;
				break;
			}
		}

		return (stack.isEmpty());
	}

	public static void main(String[] args) {
		String exp1 = "[ �(�, �)�, �[�, �]�, �{�, �}� ]";
		String exp2 = "[()]{}{[()()]()}";
		String exp3 = "[(])}";

		System.out.println("Given String : " +exp1);
		if (areBracketsBalanced(exp1))
			System.out.println("Parentheses  : Balanced");
			
		System.out.println("\nGiven String : " +exp2);
		if(areBracketsBalanced(exp2))
			System.out.println("Parentheses  : Balanced");
		
		System.out.println("\nGiven String : " +exp3);
		if(areBracketsBalanced(exp3))
			System.out.println("Parentheses  : Balanced");
			
		else
			System.out.println("Parentheses  : Not Balanced ");
	}
}
