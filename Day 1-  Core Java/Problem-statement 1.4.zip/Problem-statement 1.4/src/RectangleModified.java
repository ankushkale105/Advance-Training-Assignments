import java.util.Scanner;

public class RectangleModified {
	float length;
	float width;
	double area;
	double parameter;

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public RectangleModified() {
		length = 1;
		width = 1;
	}

	void input() {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter Length of Rectangle (Should be less than 20.0) : ");
		length = in.nextFloat();
		
		System.out.print("Enter Width of Rectangle : ");
		width = in.nextFloat();
	}

	void AreaOfRectangle() {
		area = length * width;

	}

	void PerimeterOfRectangle() {
		parameter = 2 * (length + width);

	}

	void display() {
		if (length > 0 && length < 20) {
			System.out.println("Area of the Rectangle = " + area);
			System.out.println("Parameter of the Rectangle = " + parameter);
		}

	}

	public static void main(String args[]) {

		RectangleModified object1 = new RectangleModified();
		object1.input();
		object1.AreaOfRectangle();
		object1.PerimeterOfRectangle();
		object1.display();
		System.out.println("**************************************"+"\n");
		RectangleModified object2 = new RectangleModified();
		object2.input();
		object2.AreaOfRectangle();
		object2.PerimeterOfRectangle();
		object2.display();
		System.out.println("**************************************"+"\n");
		RectangleModified object3 = new RectangleModified();
		object3.input();
		object3.AreaOfRectangle();
		object3.PerimeterOfRectangle();
		object3.display();
		System.out.println("**************************************"+"\n");
		RectangleModified object4 = new RectangleModified();
		object4.input();
		object4.AreaOfRectangle();
		object4.PerimeterOfRectangle();
		object4.display();
		System.out.println("**************************************"+"\n");
		RectangleModified object5 = new RectangleModified();
		object5.input();
		object5.AreaOfRectangle();
		object5.PerimeterOfRectangle();
		object5.display();
		System.out.println("**************************************"+"\n");

	}
}