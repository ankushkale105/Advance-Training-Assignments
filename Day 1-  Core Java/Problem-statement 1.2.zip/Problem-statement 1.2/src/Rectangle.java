import java.util.Scanner;

public class Rectangle {
	
	int length=0, breadth=0, area;


	void input() {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter length of rectangle : ");
		length = input.nextInt();
		System.out.println("Enter breadth of rectangle : ");
		breadth = input.nextInt();
		
	}
	
	void Area() {
		area = length* breadth;
	}
	
	void display() {
	    System.out.println("Area of Rectangle = " + area);
	       
	    }
	 
	public static void main (String[] args) {
		Rectangle object1 = new Rectangle();
		object1.input();
		object1.Area();
		object1.display();
		System.out.println("**************************************");
		Rectangle object2 = new Rectangle();
		object2.input();
		object2.Area();
		object2.display();
		System.out.println("**************************************");
		Rectangle object3 = new Rectangle();
		object3.input();
		object3.Area();
		object3.display();
		System.out.println("**************************************");
		Rectangle object4 = new Rectangle();
		object4.input();
		object4.Area();
		object4.display();
		System.out.println("**************************************");
		Rectangle object5 = new Rectangle();
		object5.input();
		object5.Area();
		object5.display();
		
	}
}
