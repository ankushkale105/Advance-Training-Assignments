
import java.util.Scanner;

public class CheckString {
	public static void main(String args[]) {
		String str, rev = "";

		Scanner ak = new Scanner(System.in);

		System.out.println("Enter a string :");
		str = ak.nextLine();

		// change string to uppercase
		String strupper = str.toUpperCase();
		System.out.println("String in Uppercase is : " + strupper);

		int length = str.length();
		System.out.println("Length of the String is : "+length+"\n");

		for (int i = length - 1; i >= 0; i--)
			rev = rev + str.charAt(i);

		if (str.equals(rev)) {
			System.out.println(str + " is a Palindrome");
		} else {
			System.out.println(str + " is not a Palindrome");
		}
	}
}