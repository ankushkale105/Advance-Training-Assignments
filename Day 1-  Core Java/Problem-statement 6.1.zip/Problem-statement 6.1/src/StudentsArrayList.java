
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class StudentsArrayList {

	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String> Names = new ArrayList<String>();
		int option = -1;
		System.out.println("Students Name's ArrayList ");
		try {

			while (option != 3) {
				System.out.println("\nChoose from options.\n1.Add a name\n2.Check a name\n3.Exit");
				option = Integer.parseInt(br.readLine());
				switch (option) {
				case 1: {
					System.out.println("Enter the name : ");
					String temp = br.readLine();
					Names.add(temp);
					System.out.println(temp + " had been added to List");
					break;
				}
				case 2: {
					System.out.println("Enter the name to be searched :");
					String temp = br.readLine();
					if (Names.indexOf(temp) >= 0)
						System.out.println(temp + " is present in List");
					else
						System.out.println(temp + " is not found in List");
					break;
				}
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Bye-Bye");
		}
	}
}
