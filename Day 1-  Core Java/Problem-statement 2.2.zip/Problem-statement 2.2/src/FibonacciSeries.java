
import java.util.Scanner;

public class FibonacciSeries {
	public static void main(String[] args) {

		Scanner ak = new Scanner(System.in);
		System.out.println("Enter two numbers : ");

		int num1 = ak.nextInt();
		int num2 = ak.nextInt();

		int i = 0, n = 14;
		int firstTerm = num1, secondTerm = num2;
		System.out.println("Fibonacci Series till next 13 numbers is :");

		while (i <= n) {
			System.out.print(firstTerm + ", ");

			int nextTerm ;
			nextTerm= firstTerm + secondTerm;
			firstTerm = secondTerm;
			secondTerm = nextTerm;

			i++;
		}
	}
}