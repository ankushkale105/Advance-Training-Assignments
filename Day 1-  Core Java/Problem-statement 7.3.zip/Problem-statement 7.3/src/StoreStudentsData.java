
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Hashtable;
import java.util.Scanner;

class file{
    file()
    {
        try{
        FileReader fr = new FileReader("output.txt");
        String str = "";
        int i;
	    while ((i = fr.read()) != -1)str += (char)i;
	    System.out.println("Data Stored in file : \n"+str);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
}
}

public class StoreStudentsData {
	static void solve(){
	    try{
	        System.out.println("\t***** WELCOME *****");
	        int option=-1,count=0;
	        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	        FileWriter fw = new FileWriter("output.txt");
	        while(option!=2)
	        {
	            count++;
	            System.out.println("1.Add details\n2.Exit");
	            option=Integer.parseInt(br.readLine());
	               int age,rollNo;
	               String Name,Address;
	            if(option==1)
	            {
	            	Scanner sc = new Scanner(System.in);
	        		Hashtable<String, String> hm = new Hashtable<String, String>();
	        		System.out.println("Enter the product id and name;");
	        		for (int i = 0; i < 3; i++) {
	        			hm.put(sc.next(), sc.next());
	        		}
	        		System.out.println("The Product list is:");
	        		System.out.println(hm);
	        		System.out.println("Enter the Product id to be removed:");
	        		String id = sc.next();
	        		hm.remove(id);
	        		System.out.println("Item Removed\n");
	        		System.out.println("The Product list is:");
	        		System.out.println(hm.toString());
	        		System.out.println("Enter the Product Id to be searched:");
	        		String sid = sc.next();
	        		if (hm.containsKey(sid)) {
	        			System.out.println(hm.get(sid));
	        		} else {
	        			System.out.println("Do Not Exist");
	        		}
	        		System.out.println("Do you want to enter details into file :\n1.Yes\n2.No");
	                String o=br.readLine();
	                if (o.equals("1")) {
						fw.write(hm.toString());
						System.out.println("Data Stored ");
					} else {
						fw.close();
						break;
					}
	            }
	        }
	        System.out.println("Do you want view file data on terminal :\n1.Yes\n2.No");
	        String temp=br.readLine();
	        if(temp.equals("1"))
	        new file();
	    }
	    catch(Exception e){
	        System.out.println(e);
	    }
	    finally{
	        System.out.println("Thank-You\nBye-Bye");
	    }
	}
	public static void main(String[] args) {
		solve();
	}
}


