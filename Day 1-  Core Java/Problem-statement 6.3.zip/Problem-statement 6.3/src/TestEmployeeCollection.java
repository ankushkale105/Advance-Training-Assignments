

public class TestEmployeeCollection {
	public static void main(String[] args) {
        LinkedList<Employee> linkedList = new LinkedList<Employee>(); // creation of Linked List
        
        linkedList.insertFirst(new Employee("101", "Amitabh","Mumbai"));
        linkedList.insertFirst(new Employee("102", "Sumit","NAgpur"));
        linkedList.insertFirst(new Employee("103", "Rajesh","Amravati"));
        linkedList.insertFirst(new Employee("104", "Shahrukh","Aurangabad"));
        linkedList.insertFirst(new Employee("105", "Punit","Pune"));

        linkedList.displayLinkedList();
  }
}
