

public class AddRemoveChar {

    // Print all the rotated string.
    static void printRotatedString(String str)
    {
        int len = str.length();
      
        // Generate all rotations one by one and print
        StringBuffer strbuffer;
         
        for (int i = 0; i < len; i++)
        {
            strbuffer = new StringBuffer();
             
            int j = i;  // Current index in str
            int k = 0;  // Current index in temp
      
            // Copying the second part from the point
            // of rotation.
            for (int k2 = j; k2 < str.length(); k2++) {
                strbuffer.insert(k, str.charAt(j));
                k++;
                j++;
            }
      
            // Copying the first part from the point
            // of rotation.
            j = 0;
            while (j < i)
            {
                strbuffer.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(strbuffer);
        }
    }
     
   
    public static void main(String[] args)
    {
        String  str = new String("MPHASIS");
        printRotatedString(str);
        System.out.println("MPHASIS");
    }
}
